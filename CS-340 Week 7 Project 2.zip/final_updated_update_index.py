from pymongo import MongoClient
from bson.objectid import ObjectId

class CRUD:
    def __init__(self, username, password, host, port, database, collection):
        """
        Initialize CRUD with MongoDB Connection info
        Parameters:
        :param username: (str)
        :param password: (str)
        :param host: (str)
        :param port: (str)
        :param database: (str)
        :param collection: (str)
        """
	
	# Start MongoDB connection
        self.client = MongoClient(f'mongodb://{username}:{password}@{host}:{port}')
        self.database = self.client[database]
        self.collection = self.database[collection]

    def create(self, data):
        try:
        # Add document into collection using information in json form and make sure it was done and returns data from collection
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
            
        except Exception as e:
        # Print errors
            print(f"Error in create {str(e)}")
            return False
       
    def read(self, query):
        try:
        # Find certain things using query in collection and returns list
            cursor = self.collection.find(query)
            result_list=list(cursor)
            return result_list
            
        except Exception as e:
        # Print errors
            print(f"Error in read {str(e)}")
            return []
   
    # finish update method
    
    def update(self, query, data):
    	try:
    	# Updates documents in the collection by using query to find and replace then returns amount changed
    		result = self.collection.update_many(query, {"$set": data})
    		return result.modified_count
    	except Exception as e:
    	# Print errors
    		print(f"Error in update {str(e)}")
    		return 0
    
    # finish the delete method
    
    def delete(self, query):
    	try:
    	#Deletes documents in the collection and return number deleted
    		result = self.collection.delete_many(query)
    		return result.deleted_count
    		
    	except Exception as e:
    	# Print errors
    		print(f"Error in delete: {str(e)}")
    		return 0
	
   
def main():

	# Initialize CRUD class with MongoDB info
   	crud = CRUD("aacuser", "root", "nv-desktop-services.apporto.com", "30393", "AAC", "animals")


if __name__ == "__main__":
    main()

####################
#                  #
#   Bonus Info     #
#                  #
####################
# for testing
# now test out your CRUD class

    

   # data=crud.read({"breed" : "Domestic Shorthair Mix"})

  #  for i in range(3):
 #       print(data[i])
 # see https://pymongo.readthedocs.io/en/stable/tutorial.html

